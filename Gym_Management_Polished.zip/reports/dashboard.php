<!DOCTYPE html>
<html>
<head>
<title>Reports</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
<h1>Reports Dashboard</h1>
<div class="cards">
<div class="card"><h2>Total Members</h2><p>Statistics</p></div>
<div class="card"><h2>Total Trainers</h2><p>Statistics</p></div>
<div class="card"><h2>Revenue</h2><p>Summary</p></div>
</div>
</div>
</body>
</html>