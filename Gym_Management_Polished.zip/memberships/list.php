<!DOCTYPE html>
<html>
<head>
<title>Memberships</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
<h1>Memberships Module</h1>
<p>Copy the CRUD files from the earlier module ZIPs into this folder.</p>
</div>
</body>
</html>