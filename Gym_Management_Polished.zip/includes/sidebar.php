<div class="sidebar">
<h2 style="color:white;text-align:center;">GYM ADMIN</h2>
<a href="../index.php">Dashboard</a>
<a href="../members/list.php">Members</a>
<a href="../trainers/list.php">Trainers</a>
<a href="../plans/list.php">Plans</a>
<a href="../schedules/list.php">Schedules</a>
<a href="../memberships/list.php">Memberships</a>
<a href="../reports/dashboard.php">Reports</a>
</div>
